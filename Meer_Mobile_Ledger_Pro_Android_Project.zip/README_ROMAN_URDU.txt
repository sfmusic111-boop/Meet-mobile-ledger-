MEER MOBILE LEDGER PRO — Android App Project (v2.0)

FEATURES
- 4-digit PIN lock (first launch par PIN banayein; baad mein unlock).
- Mobile model, IMEI 1/2, purchase date/price, sale date/price.
- Mobile profit/loss auto calculate hota hai.
- Meer, Farhan, Sajid ki daily income.
- Expense categories: Daily Kharch, Committee, Daily VC, Home, Plot Kist, Rent, Other.
- Saved records par tap karke Edit ya Delete.
- Current-month dashboard and expense category totals.
- CSV backup export; CSV ko Microsoft Excel ya Google Sheets mein open kar sakte hain.
- Offline local SQLite database.

IMPORTANT DATA / SECURITY NOTES
- PIN app ke local preferences mein rakha gaya hai; yeh basic app-level lock hai, high-security encryption nahi.
- Records phone ke local database mein hain. App uninstall ya phone reset se data loss ho sakta hai.
- Regularly Home > Export Full Backup (CSV) karein aur backup file ko safe jagah rakhein.
- CSV export backup hai; is version mein CSV restore/import abhi shamil nahi.
- IMEI sensitive identifier hai. Phone lock aur backup file private rakhein.
- Date YYYY-MM-DD format mein enter karein, e.g. 2026-11-19.
- Reports current month ke dates par filter hoti hain.
- Brothers income minus expenses simple cash view hai. Mobile profit separately dikhaya jata hai taake double counting na ho.

FREE APK BUILD WITH GITHUB
1. GitHub par free account banayein.
2. New repository banayein.
3. Is ZIP ko extract karke tamam project files repository ke root mein upload karein.
4. Actions tab open karein. Android APK workflow automatic ya manually run ho sakta hai.
5. Successful run ke Artifacts section se Meer-Mobile-Ledger-Pro-APK download karein.
6. Artifact ZIP extract karein; app-debug.apk install karein.
7. Android settings mein zarurat par browser/files app ko "Install unknown apps" permission dein.

ANDROID STUDIO BUILD
Open project > Gradle sync > Build > Build APK(s).
APK path: app/build/outputs/apk/debug/app-debug.apk

This is a starter accounting app. Test it with sample data and keep backups before relying on it for business accounts.
