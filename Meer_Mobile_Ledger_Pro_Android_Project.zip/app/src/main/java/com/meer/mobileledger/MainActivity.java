package com.meer.mobileledger;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, body; String page="home";
    int navy=Color.rgb(16,42,67), teal=Color.rgb(11,143,135);
    static final int EXPORT_REQ=77;

    public void onCreate(Bundle b){
        super.onCreate(b); db=new DB(this);
        String saved=getPreferences(0).getString("pin","");
        if(saved.isEmpty()) pinDialog(true); else pinDialog(false);
    }
    TextView txt(String s,int size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(5,8,5,8); return t;
    }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextSize(15); return e; }
    Button btn(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v->r.run()); return b; }
    void pinDialog(boolean first){
        LinearLayout box=new LinearLayout(this); box.setPadding(24,8,24,8); box.setOrientation(1);
        TextView msg=txt(first?"Apna 4-digit PIN banayein":"Apna 4-digit PIN enter karein",16,navy); box.addView(msg);
        EditText pin=field("4-digit PIN"); pin.setInputType( android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD ); box.addView(pin);
        new AlertDialog.Builder(this).setTitle("Meer Mobile Ledger Security").setView(box)
        .setCancelable(false).setPositiveButton(first?"Save PIN":"Unlock",(d,w)->{
            String p=pin.getText().toString();
            if(p.length()!=4){ toast("PIN exactly 4 digits ka hona chahiye."); pinDialog(first); return; }
            String old=getPreferences(0).getString("pin","");
            if(!first && !p.equals(old)){ toast("Ghalat PIN. Dobara koshish karein."); pinDialog(false); return; }
            if(first)getPreferences(0).edit().putString("pin",p).apply();
            show("home");
        }).show();
    }
    void show(String p){
        page=p; root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(246,248,250));
        TextView header=txt("MEER MOBILE LEDGER PRO",19,Color.WHITE); header.setBackgroundColor(navy); header.setPadding(16,20,12,20); root.addView(header);
        HorizontalScrollView hs=new HorizontalScrollView(this); LinearLayout nav=new LinearLayout(this);
        String[][] tabs={{"Home","home"},{"Mobiles","mobiles"},{"Income","income"},{"Expenses","expenses"},{"Reports","reports"}};
        for(String[] a:tabs) nav.addView(btn(a[0],()->show(a[1])));
        hs.addView(nav); root.addView(hs);
        ScrollView sc=new ScrollView(this); body=new LinearLayout(this); body.setPadding(16,10,16,24); body.setOrientation(1); sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        if(p.equals("home"))home(); else if(p.equals("mobiles"))mobiles(); else if(p.equals("income"))income(); else if(p.equals("expenses"))expenses(); else reports();
    }
    void heading(String s){ body.addView(txt(s,21,navy)); }
    void line(String s){ body.addView(txt(s,14,Color.DKGRAY)); }
    void add(ArrayList<EditText> a,String hint){EditText e=field(hint);a.add(e);body.addView(e);}
    String v(ArrayList<EditText>a,int i){return a.get(i).getText().toString().trim();}
    double n(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    String fmt(double x){return String.format(Locale.US,"%,.0f",x);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void home(){
        heading("Assalam-o-Alaikum!");
        line("Aapki shop ka digital hisaab — offline aur phone mein save.");
        card("Mobile Purchase / Sale","Model, IMEI, purchase, sale aur profit/loss.",()->show("mobiles"));
        card("Brothers Daily Income","Meer, Farhan aur Sajid ki daily earning.",()->show("income"));
        card("Daily Expenses","Committee, VC, home, plot kist, rent aur doosre kharch.",()->show("expenses"));
        card("Monthly Dashboard","Mahine ka income, expense aur business summary.",()->show("reports"));
        body.addView(btn("Change PIN",()->changePin()));
        body.addView(btn("Export Full Backup (CSV)",()->exportBackup()));
        line("Data isi Android phone ke local database mein rehta hai. Regular backup export karte rahein.");
    }
    void card(String title,String desc,Runnable r){
        LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(14,8,14,8);
        c.setBackgroundColor(Color.WHITE); c.addView(txt(title,17,teal)); c.addView(txt(desc,13,Color.DKGRAY));
        c.setOnClickListener(w->r.run()); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,8,0,8);body.addView(c,lp);
    }
    void mobiles(){
        heading("Mobile Purchase & Sale");
        ArrayList<EditText> f=new ArrayList<>();
        add(f,"Mobile Model");add(f,"IMEI 1");add(f,"IMEI 2 (optional)");
        add(f,"Purchase Date YYYY-MM-DD");add(f,"Purchase Price Rs.");
        add(f,"Sale Date YYYY-MM-DD (blank if unsold)");add(f,"Sale Price Rs. (blank if unsold)");
        body.addView(btn("Save Mobile",()->{
            if(v(f,0).isEmpty()||v(f,4).isEmpty()){toast("Model aur purchase price zaroori hain.");return;}
            double buy=n(v(f,4)), sell=n(v(f,6));
            db.getWritableDatabase().execSQL("INSERT INTO mobiles(model,imei1,imei2,pdate,buy,sdate,sell,profit) VALUES(?,?,?,?,?,?,?,?)",
            new Object[]{v(f,0),v(f,1),v(f,2),v(f,3),buy,v(f,5),sell,sell>0?sell-buy:0});
            toast("Mobile save ho gaya.");show("mobiles");
        }));
        heading("Saved Mobiles — tap for Edit / Delete");
        listRows("mobiles","SELECT id, model || ' | IMEI: ' || imei1 || ' | Buy: ' || buy || ' | Sale: ' || sell || ' | P/L: ' || profit FROM mobiles ORDER BY id DESC");
    }
    void income(){
        heading("Brothers Daily Income");
        ArrayList<EditText> f=new ArrayList<>();add(f,"Date YYYY-MM-DD");add(f,"Meer Income Rs.");add(f,"Farhan Income Rs.");add(f,"Sajid Income Rs.");
        body.addView(btn("Save Daily Income",()->{
            if(v(f,0).isEmpty()){toast("Date zaroor likhein.");return;}
            db.getWritableDatabase().execSQL("INSERT INTO income(date,meer,farhan,sajid) VALUES(?,?,?,?)",
            new Object[]{v(f,0),n(v(f,1)),n(v(f,2)),n(v(f,3))});toast("Income save ho gayi.");show("income");
        }));
        heading("Saved Income — tap for Edit / Delete");
        listRows("income","SELECT id, date || ' | Meer: ' || meer || ' | Farhan: ' || farhan || ' | Sajid: ' || sajid FROM income ORDER BY id DESC");
    }
    void expenses(){
        heading("Daily Expenses");
        ArrayList<EditText> f=new ArrayList<>();add(f,"Date YYYY-MM-DD");
        Spinner sp=new Spinner(this);String[] cats={"Daily Kharch","Committee","Daily VC","Home","Plot Kist","Rent","Other"};sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats));body.addView(sp);
        add(f,"Amount Rs.");add(f,"Notes (optional)");
        body.addView(btn("Save Expense",()->{
            if(v(f,0).isEmpty()||v(f,1).isEmpty()){toast("Date aur amount zaroori hain.");return;}
            db.getWritableDatabase().execSQL("INSERT INTO expenses(date,category,amount,notes) VALUES(?,?,?,?)",
            new Object[]{v(f,0),sp.getSelectedItem().toString(),n(v(f,1)),v(f,2)});
            toast("Expense save ho gaya.");show("expenses");
        }));
        heading("Saved Expenses — tap for Edit / Delete");
        listRows("expenses","SELECT id, date || ' | ' || category || ' | Rs.' || amount || ' | ' || notes FROM expenses ORDER BY id DESC");
    }
    void listRows(String table,String sql){
        Cursor c=db.getReadableDatabase().rawQuery(sql,null);
        if(c.getCount()==0){line("Abhi koi record nahi.");c.close();return;}
        while(c.moveToNext()){
            final long id=c.getLong(0); String label=c.getString(1);
            TextView row=txt("• "+label,14,Color.DKGRAY); row.setBackgroundColor(Color.WHITE);
            row.setOnClickListener(w->recordActions(table,id)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);body.addView(row,lp);
        } c.close();
    }
    void recordActions(String table,long id){
        String[] opts={"Edit","Delete","Cancel"};
        new AlertDialog.Builder(this).setTitle("Record Options").setItems(opts,(d,which)->{
            if(which==0) editRecord(table,id);
            if(which==1)new AlertDialog.Builder(this).setMessage("Kya aap ye record delete karna chahte hain?")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete",(x,y)->{db.getWritableDatabase().delete(table,"id=?",new String[]{""+id});show(page);}).show();
        }).show();
    }
    void editRecord(String table,long id){
        SQLiteDatabase sql=db.getWritableDatabase();
        Cursor c=sql.rawQuery("SELECT * FROM "+table+" WHERE id=?",new String[]{""+id});
        if(!c.moveToFirst()){c.close();return;}
        LinearLayout box=new LinearLayout(this);box.setPadding(20,4,20,4);box.setOrientation(1);
        ArrayList<EditText> es=new ArrayList<>();
        int count=table.equals("mobiles")?7:(table.equals("income")?4:4);
        String[] names=table.equals("mobiles")?new String[]{"Model","IMEI 1","IMEI 2","Purchase Date","Purchase Price","Sale Date","Sale Price"}:
            (table.equals("income")?new String[]{"Date","Meer","Farhan","Sajid"}:new String[]{"Date","Category","Amount","Notes"});
        int[] cols=table.equals("mobiles")?new int[]{1,2,3,4,5,6,7}:(table.equals("income")?new int[]{1,2,3,4}:new int[]{1,2,3,4});
        for(int i=0;i<count;i++){EditText e=field(names[i]);e.setText(c.getString(cols[i]));es.add(e);box.addView(e);}
        c.close();
        new AlertDialog.Builder(this).setTitle("Edit Record").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            ContentValues cv=new ContentValues();
            if(table.equals("mobiles")){
                cv.put("model",es.get(0).getText().toString());cv.put("imei1",es.get(1).getText().toString());cv.put("imei2",es.get(2).getText().toString());
                cv.put("pdate",es.get(3).getText().toString());double buy=n(es.get(4).getText().toString());double sell=n(es.get(6).getText().toString());
                cv.put("buy",buy);cv.put("sdate",es.get(5).getText().toString());cv.put("sell",sell);cv.put("profit",sell>0?sell-buy:0);
            }else if(table.equals("income")){
                cv.put("date",es.get(0).getText().toString());cv.put("meer",n(es.get(1).getText().toString()));cv.put("farhan",n(es.get(2).getText().toString()));cv.put("sajid",n(es.get(3).getText().toString()));
            }else{
                cv.put("date",es.get(0).getText().toString());cv.put("category",es.get(1).getText().toString());cv.put("amount",n(es.get(2).getText().toString()));cv.put("notes",es.get(3).getText().toString());
            }
            sql.update(table,cv,"id=?",new String[]{""+id});show(page);
        }).show();
    }
    void reports(){
        heading("Monthly Business Dashboard");
        String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        line("Current month: "+month);
        double me=db.sum("SELECT COALESCE(SUM(meer),0) FROM income WHERE date LIKE '"+month+"%'");
        double fa=db.sum("SELECT COALESCE(SUM(farhan),0) FROM income WHERE date LIKE '"+month+"%'");
        double sa=db.sum("SELECT COALESCE(SUM(sajid),0) FROM income WHERE date LIKE '"+month+"%'");
        double ex=db.sum("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date LIKE '"+month+"%'");
        double mp=db.sum("SELECT COALESCE(SUM(profit),0) FROM mobiles WHERE sdate LIKE '"+month+"%'");
        line("Meer income: Rs. "+fmt(me));line("Farhan income: Rs. "+fmt(fa));line("Sajid income: Rs. "+fmt(sa));
        line("Total brothers income: Rs. "+fmt(me+fa+sa));line("Total expenses: Rs. "+fmt(ex));
        line("Mobile profit/loss recorded this month: Rs. "+fmt(mp));
        line("Income minus expenses: Rs. "+fmt(me+fa+sa-ex));
        line("Unsold stock count: "+(long)db.sum("SELECT COUNT(*) FROM mobiles WHERE sell=0"));
        line("Expense breakdown:");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category, SUM(amount) FROM expenses WHERE date LIKE '"+month+"%' GROUP BY category",null);
        while(c.moveToNext())line(c.getString(0)+": Rs. "+fmt(c.getDouble(1)));c.close();
        line("Important: Mobile profit alag report hota hai. Agar woh brothers ki income mein pehle se add hai to double count na karein.");
    }
    void changePin(){
        LinearLayout box=new LinearLayout(this);box.setPadding(20,4,20,4);box.setOrientation(1);
        EditText old=field("Current PIN");old.setInputType(18);EditText ne=field("New 4-digit PIN");ne.setInputType(18);box.addView(old);box.addView(ne);
        new AlertDialog.Builder(this).setTitle("Change PIN").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            String current=getPreferences(0).getString("pin","");
            if(!old.getText().toString().equals(current)||ne.getText().toString().length()!=4){toast("Current PIN ya new PIN ghalat hai.");return;}
            getPreferences(0).edit().putString("pin",ne.getText().toString()).apply();toast("PIN update ho gaya.");
        }).show();
    }
    void exportBackup(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"Meer_Mobile_Ledger_Backup.csv");startActivityForResult(i,EXPORT_REQ);
    }
    protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==EXPORT_REQ&&res==RESULT_OK&&data!=null){
            try{
                OutputStream out=getContentResolver().openOutputStream(data.getData());
                Writer w=new OutputStreamWriter(out,"UTF-8");
                w.write("SECTION,ID,FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,FIELD6,FIELD7,FIELD8\n");
                exportTable(w,"MOBILE","SELECT * FROM mobiles");
                exportTable(w,"INCOME","SELECT * FROM income");
                exportTable(w,"EXPENSE","SELECT * FROM expenses");
                w.flush();w.close();toast("CSV backup export ho gaya. Excel mein open kar sakte hain.");
            }catch(Exception e){toast("Backup export nahi ho saka: "+e.getMessage());}
        }
    }
    void exportTable(Writer w,String section,String query)throws Exception{
        Cursor c=db.getReadableDatabase().rawQuery(query,null);
        while(c.moveToNext()){
            w.write(section);for(int i=0;i<c.getColumnCount();i++){String s=c.isNull(i)?"":c.getString(i);w.write(","+csv(s));}w.write("\n");
        }c.close();
    }
    String csv(String s){return "\""+s.replace("\"","\"\"")+"\"";}
    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"meer_ledger_pro.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE mobiles(id INTEGER PRIMARY KEY AUTOINCREMENT,model TEXT,imei1 TEXT,imei2 TEXT,pdate TEXT,buy REAL,sdate TEXT,sell REAL,profit REAL)");
            d.execSQL("CREATE TABLE income(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,meer REAL,farhan REAL,sajid REAL)");
            d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,category TEXT,amount REAL,notes TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        double sum(String q){Cursor c=getReadableDatabase().rawQuery(q,null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    }
}
